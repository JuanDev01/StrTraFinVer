const express = require("express");
const router = express.Router();
const authController = require("../controllers/auth");
const homeController = require("../controllers/home");
const postsController = require("../controllers/posts");
const { ensureAuth, ensureGuest } = require("../middleware/auth");

//Main Routes - simplified for now
router.get("/", homeController.getIndex);
router.get("/profile", ensureAuth, postsController.getProfile);
router.get("/feed", ensureAuth, postsController.getFeed);
router.get("/login", authController.getLogin);
router.post("/login", authController.postLogin);
router.get("/logout", authController.logout);
router.get("/signup", authController.getSignup);
router.post("/signup", authController.postSignup);
router.get("/about", (req, res) => {
    res.render("about");
  });
  router.get("/blog-standard", (req, res) => {
    res.render("blog-standard");
  });
  router.get("/cart", (req, res) => {
    res.render("cart");
  });
  router.get("/checkout", (req, res) => {
    res.render("checkout");
  });
  router.get("/contact", (req, res) => {
    res.render("contact");
  });
  router.get("/course-details-2", (req, res) => {
    res.render("course-details-2");
  });
  router.get("/error", (req, res) => {
    res.render("error");
  });
  router.get("/feed", (req, res) => {
    res.render("feed");
  });
  router.get("/index", (req, res) => {
    res.render("index");
  });
  router.get("/login", (req, res) => {
    res.render("login");
  });
  router.get("/my-account", (req, res) => {
    res.render("my-account");
  });
  router.get("/post-payment", (req, res) => {
    res.render("post-payment");
  });
  router.get("/post", (req, res) => {
    res.render("post");
  });
  router.get("/privacy-policy", (req, res) => {
    res.render("privacy-policy");
  });
  router.get("/profile", (req, res) => {
    res.render("profile");
  });
  router.get("/register", (req, res) => {
    res.render("register");
  });
  router.get("/signup", (req, res) => {
    res.render("signup");
  });






module.exports = router;
